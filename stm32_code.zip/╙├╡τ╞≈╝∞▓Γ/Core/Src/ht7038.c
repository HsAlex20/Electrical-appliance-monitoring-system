/*
 * ht7038.c
 * spiȫ������GPIO��ģ��ʱ��ķ�ʽ
 *     
 */
#include "ht7038.h"

#define DELAY 3




void delay(unsigned int cnt)//��ʱ����
{
	unsigned int i,j;
	for(i=0;i<cnt;i++)
	{
		for(j=0;j<100;j++)
		{
			;
		}
	}
}


void att7038_Init(void)//�Լ��ģ��HT7038�ĳ�ʼ��
{
	delay(10000);
	att7038_Write(0xC9,0x5A); //
	delay(100);
	att7038_Write(0x01,0x89fe); //
	delay(100);
	att7038_Write(0x31,0x3521);

	delay(10000);
	att7038_Write(0xc9,0x5b); //
	att7038_Write(0xc6,0x5b); //
	delay(10000);


}


void att7038_Write(unsigned char addr/*д�����ݵĵ�ַ*/,unsigned int dat/*д�����ݵ�����*/)//��spiд����
{
	unsigned char i;

	att7038_CS_Low();
	att7038_SCK_Low();

	addr |= 0x80;
	delay(10);
	for(i=0;i<8;i++)
	{
		att7038_SCK_High();
		if(addr&0x80)
		{
			att7038_MOSI_High();
		}
		else
		{
			att7038_MOSI_Low();
		}

		addr = addr << 1;
		delay(DELAY);
		att7038_SCK_Low();
		delay(DELAY);
	}
	for(i=0;i<24;i++)
	{
		att7038_SCK_High();
		if(dat&0x800000)
		{
			att7038_MOSI_High();
		}
		else
		{
			att7038_MOSI_Low();
		}

		dat = dat << 1;
		delay(DELAY);
		att7038_SCK_Low();
		delay(DELAY);
	}

	att7038_CS_High();
	att7038_SCK_Low();
	att7038_MOSI_Low();
}

unsigned int att7038_Read(unsigned char addr)//��spi������
{
	unsigned char i;
	unsigned int dat=0;

	att7038_CS_Low();
	att7038_SCK_Low();
	delay(10);

	for(i=0;i<8;i++)
	{
		att7038_SCK_High();
		if(addr&0x80)
		{
			att7038_MOSI_High();
		}
		else
		{
			att7038_MOSI_Low();
		}

		addr = addr << 1;
		delay(DELAY);
		att7038_SCK_Low();
		delay(DELAY);
	}

	delay(10);

	for(i=0;i<24;i++)
	{
		att7038_SCK_High();
		delay(DELAY);
		dat =dat << 1;
		if(att7038_MISO_STA())
		{
			dat |= 1;
		}

		att7038_SCK_Low();
		delay(DELAY);
	}

	att7038_CS_High();
	att7038_SCK_Low();
	att7038_MOSI_Low();

	return dat;
}


