/*
 * ht7038.c
 *
 *  Created on: Nov 6, 2021
 *      Author: zhang
 */

#ifndef INC_HT7038_C_
#define INC_HT7038_C_

#include "main.h"
#include "gpio.h"



#define att7038_CS_Low()  		HAL_GPIO_WritePin(SPI_NSS_GPIO_Port,SPI_NSS_Pin,0)
#define att7038_CS_High()  		HAL_GPIO_WritePin(SPI_NSS_GPIO_Port,SPI_NSS_Pin,1)
#define att7038_SCK_Low()  		HAL_GPIO_WritePin(SPI_SCK_GPIO_Port,SPI_SCK_Pin,0)
#define att7038_SCK_High()  	HAL_GPIO_WritePin(SPI_SCK_GPIO_Port,SPI_SCK_Pin,1)
#define att7038_MOSI_Low()  	HAL_GPIO_WritePin(SPI_MOSI_GPIO_Port,SPI_MOSI_Pin,0)
#define att7038_MOSI_High() 	HAL_GPIO_WritePin(SPI_MOSI_GPIO_Port,SPI_MOSI_Pin,1)
#define att7038_MISO_STA() 		HAL_GPIO_ReadPin(SPI_MISO_GPIO_Port, SPI_MISO_Pin)//����spi�����ŵĵ�λ��ֵ����




unsigned int att7038_Read(unsigned char addr);
void att7038_Write(unsigned char addr,unsigned int dat);
void att7038_GPIO_Init(void);
void att7038_Init(void);
void delay(unsigned int cnt);





#endif /* INC_HT7038_C_ */
